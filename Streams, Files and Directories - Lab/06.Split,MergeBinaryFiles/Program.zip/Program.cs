﻿namespace SplitMergeBinaryFile
{
    using System;
    using System.IO;
    using System.Linq;

    public class SplitMergeBinaryFile
    {
        static void Main()
        {
            string sourceFilePath = @"..\..\..\Files\example.png";
            string joinedFilePath = @"..\..\..\Files\example-joined.png";
            string partOnePath = @"..\..\..\Files\part-1.bin";
            string partTwoPath = @"..\..\..\Files\part-2.bin";

            SplitBinaryFile(sourceFilePath, partOnePath, partTwoPath);
            MergeBinaryFiles(partOnePath, partTwoPath, joinedFilePath);
        }
        public static void SplitBinaryFile(string sourceFilePath, string partOneFilePath, string partTwoFilePath)
        {
            // Четем байтовете от входния файл
            byte[] fileBytes = File.ReadAllBytes(sourceFilePath);
            int totalBytes = fileBytes.Length;

            // Определяме размера на частите
            int partOneSize = (totalBytes + 1) / 2; // Първата част е по-голяма при нечетен размер
            int partTwoSize = totalBytes / 2;

            // Записваме първата част
            using (FileStream partOneStream = new FileStream(partOneFilePath, FileMode.Create))
            {
                partOneStream.Write(fileBytes, 0, partOneSize);
            }

            // Записваме втората част
            using (FileStream partTwoStream = new FileStream(partTwoFilePath, FileMode.Create))
            {
                partTwoStream.Write(fileBytes, partOneSize, partTwoSize);
            }
        }
        public static void MergeBinaryFiles(string partOneFilePath, string partTwoFilePath, string joinedFilePath)
        {
            using (FileStream joinedStream = new FileStream(joinedFilePath, FileMode.Create))
            {
                // Четем и записваме първата част
                using (FileStream partOneStream = new FileStream(partOneFilePath, FileMode.Open))
                {
                    partOneStream.CopyTo(joinedStream);
                }

                // Четем и записваме втората част
                using (FileStream partTwoStream = new FileStream(partTwoFilePath, FileMode.Open))
                {
                    partTwoStream.CopyTo(joinedStream);
                }
            }
        }
    }
}
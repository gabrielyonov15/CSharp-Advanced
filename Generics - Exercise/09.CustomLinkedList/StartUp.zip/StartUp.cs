﻿namespace CustomDoublyLinkedList
{
    class StartUp
    {
        public static void Main(string[] args)
        {
            //DoublyLinkedList list = new DoublyLinkedList();
            //list.AddFirst(1);
            //list.AddFirst(2);
            //list.AddLast(3);
            //list.AddLast(4);
            //Console.WriteLine("Elements in list:");
            //list.ForEach(value => Console.Write(value + " "));
            //Console.WriteLine();
            //Console.WriteLine("Removing first: " + list.RemoveFirst());
            //Console.WriteLine("Removing last: " + list.RemoveLast());
            //Console.WriteLine("Elements in list after removal:");
            //list.ForEach(value => Console.Write(value + " "));
            //Console.WriteLine();
            //int[] array = list.ToArray();
            //Console.WriteLine("Array: " + string.Join(", ", array));
        }
    }
}